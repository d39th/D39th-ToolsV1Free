__title__ = 'd39th ToolsV1'
__author__ = 'd39th toolsV1'
__copyright__ = 'discord.gg/d39th'
__version__ = '1.0.0'

import asyncio
import base64
import codecs
import concurrent.futures
import ctypes
import http
import importlib
import json
import os
import random
import re
import secrets
import shutil
import socket
import string
import subprocess
import sys
import tempfile
import threading
import time
import tkinter as tk
import urllib.request
from base64 import b64decode
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from json import loads
from os import getlogin, listdir
from os.path import isfile, join
from pathlib import Path
from re import findall
from tkinter import filedialog
from urllib.parse import urljoin, urlparse
from urllib.request import urlretrieve

required_modules = [
    "aiohttp",
    "httpx",
    "pytz",
    "requests",
    "tls_client",
    "undetected_chromedriver",
    "websocket",
    "beautifulsoup4",
    "colorama",
    "pycryptodome",
    "faker",
    "pytube",
    "win32crypt",
]

for module in required_modules:
    try:
        importlib.import_module(module)
    except ModuleNotFoundError:
        print(f"Module {module} not found, installing...")
        subprocess.run(["pip", "install", module], check=True)
        print(f"Module {module} installed successfully")

import aiohttp
import httpx
import pytz
import requests
import tls_client
import undetected_chromedriver as uc
import websocket
from bs4 import BeautifulSoup
from colorama import Fore, Style
from Crypto.Cipher import AES
from faker import Faker
from pytube import YouTube
from tls_client import Session
from win32crypt import CryptUnprotectData

from .Funcs2.Discord_Nuker import Discord_nuker
from .Funcs2.get_own_token import get_own_token
from .Funcs2.Nitro_gift_checker import check_codes
from .Funcs2.Pc_cleaner import Cleaner
from .Funcs2.Status_Rotator import status_changer
from .Funcs2.Token_editor import token_editor
from .Funcs2.Token_Mail_verifier import TokenMailverifier
from .Funcs2.Token_Nuker import Token_nuker
from .Funcs2.Token_onliner import online_tokens
from .Funcs2.Token_pass_changer import pass_changer
from .Funcs2.TokenLogin import token_login
from .Funcs3.converter import youtube_converter
from .Funcs3.gen_test_token import gen_token
from .Funcs3.ip_lookup import ip_lookup
from .Funcs3.picture_scraper import scrape_Avatars
from .Funcs3.remove_discord_injection import RemoveInjection
from .Funcs3.social_menu import social_menu
from .Funcs3.token_guild_count_checker import guild_count
from .Funcs3.token_huminazor import procces_hm
from .Funcs3.token_info import fetch_user_details
from .Funcs3.token_leave_groups import leave_groups
from .Funcs3.token_message_everywhere import meessage_everywhere_spam
from .Funcs3.token_payment_checker import check_payments
from .Funcs3.token_watermarker import token_wartermarker
from .Funcs4.id_to_tokend import id__token
from .Funcs4.ip_grabber import make_ip_grabber
from .Funcs4.message_logger import message_logger
from .Funcs4.serial_changer import serial_changer
from .Funcs4.serial_checker import check_serials
from .Funcs.clear import clear_input, clear_output
from .Funcs.faker import main_faker
from .Funcs.obf import obfuscate
from .Funcs.proxy_checker import check_proxys
from .Funcs.proxy_scraper import Proxy_scraper
from .Funcs.remove_doubles import remove_duplicates
from .Funcs.start import StartupTool
from .Funcs.token_checker import Token_checker
from .Funcs.token_formater import formater
from .Funcs.token_guild_check import check_tokens_guild
from .Funcs.token_guild_leaver import token_leave_server
from .Funcs.token_sorter import sort_tokens
from .Funcs.token_spammer import token_spammer
from .Funcs.webhook_tool import Webhook_tool

banner = f'''{Fore.LIGHTMAGENTA_EX}

                                   ██████╗ ██████╗  █████╗ ████████╗██╗  ██╗
                                   ██╔══██╗╚════██╗██╔══██╗╚══██╔══╝██║  ██║
                                   ██║  ██║ █████╔╝╚██████║   ██║   ███████║
                                   ██║  ██║ ╚═══██╗ ╚═══██║   ██║   ██╔══██║
                                   ██████╔╝██████╔╝ █████╔╝   ██║   ██║  ██║
                                   ╚═════╝ ╚═════╝  ╚════╝    ╚═╝   ╚═╝  ╚═╝


                                                discord.gg/d39th
    '''

def donate_infos():
    print(f"{Fore.RESET}Btc: {Fore.GREEN}bc1q2e86tshk0cs05sty5ajlc6n6j8esutj2umcjtz")
    print(f"{Fore.RESET}Ltc: {Fore.GREEN}Lf5vGeL8BwNE84QGyAh1TJWuDxhyKS7QTD")
    print(f"{Fore.RESET}Eth: {Fore.GREEN}0xa66343933221706294c29935FC8da88b025D501B")
    input("Press Enter To continue...")

